package com.eazybytes.eazySchoolApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EazySchoolAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
