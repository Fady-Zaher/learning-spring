package com.eazybytes.eazySchoolApp.model;

import lombok.Data;

import javax.persistence.*;

/*
@Data annotation is provided by Lombok library which generates getter, setter,
equals(), hashCode(), toString() methods & Constructor at compile time.
This makes our code short and clean.
* */
@Data
@Entity
@Table(name="holidays")
public class Holiday extends BaseEntity {
    @Id
    @Column(name="days")
    private String day;

    private String reason;

    @Enumerated(EnumType.STRING)
    private Type type;

    public enum Type{
        FESTIVAL,FEDERAL
    }
/*
    public Holiday(String day, String reason, Type type){
        this.day = day;
        this.reason = reason;
        this.type = type;
    }

    public String getDay() {
        return day;
    }

    public String getReason() {
        return reason;
    }

    public Type getType() {
        return type;
    }
 */
}
