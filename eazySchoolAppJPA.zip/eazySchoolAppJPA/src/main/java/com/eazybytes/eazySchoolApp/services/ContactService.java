package com.eazybytes.eazySchoolApp.services;

import com.eazybytes.eazySchoolApp.config.AppPropertiesVariablesConfig;
import com.eazybytes.eazySchoolApp.constants.EazySchoolConstants;
import com.eazybytes.eazySchoolApp.model.Contact;
import com.eazybytes.eazySchoolApp.repositories.ContactRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class ContactService {
//    replaced by @Slf4j annotation
//    private Logger log = LoggerFactory.getLogger(ContactService.class);

    @Autowired
    private ContactRepository contactRepository;

    @Autowired
    private AppPropertiesVariablesConfig appPropertiesVariables;

    public boolean saveMessageDetails(Contact contact){
        boolean isSaved = false;
        contact.setStatus(EazySchoolConstants.OPEN);
// replaced by the audit package
/*
        contact.setCreatedAt(LocalDateTime.now());
        contact.setCreatedBy(EazySchoolConstants.ANONYMOUS);

 */
        Contact savedContact = contactRepository.save(contact);

        if ( savedContact!=null && savedContact.getContactId() > 0) {
            isSaved = true;
        }

        return isSaved;
    }

    public List<Contact> findOpenMessages (){
        return contactRepository.findByStatus(EazySchoolConstants.OPEN);
    }

    public boolean updateMsgStatus(int contactId ){//, String status, String user){

        boolean isUpdated = false;
        Optional<Contact> contact = contactRepository.findById(contactId);
        contact.ifPresent(contact1 -> {
            contact1.setStatus(EazySchoolConstants.CLOSE);
// replaced by the audit package
/*
            contact1.setUpdatedBy(user);
            contact1.setUpdatedAt(LocalDateTime.now());
 */
        });
// using Spring JPA
/*        Contact updatedContact = contactRepository.save(contact.get());
        if ( updatedContact!=null && updatedContact.getUpdatedBy()!=null ) {
            isUpdated = true;
        }
*/
// using Custom Query
        int noUpdatedRecords = contactRepository.updateStatusById(EazySchoolConstants.CLOSE,contactId);
        if (noUpdatedRecords > 0){
            isUpdated = true;
        }
        return isUpdated;
    }

    public Page<Contact> findOpenMessagesByPage(int pageNum,String sortField, String sortDir){

//        int pageSize = EazySchoolConstants.pageSize;
        int pageSize = appPropertiesVariables.getPageSize();
        if (appPropertiesVariables.getContact() != null && appPropertiesVariables.getContact().get("pageSize") != null){
            pageSize= Integer.parseInt(appPropertiesVariables.getContact().get("pageSize").trim());
        }

        Pageable pageable = PageRequest.of(pageNum -1,pageSize,
                sortDir.equals("asc") ? Sort.by(sortField).ascending()
                                      : Sort.by(sortField).descending());
// without Query in repository
//        Page<Contact> contacts = contactRepository.findByStatus(EazySchoolConstants.OPEN,pageable);
// with JPQL custom Query
        Page<Contact> contacts = contactRepository.findByStatusUsingQuery(EazySchoolConstants.OPEN,pageable);
                return contacts;
    }
}
