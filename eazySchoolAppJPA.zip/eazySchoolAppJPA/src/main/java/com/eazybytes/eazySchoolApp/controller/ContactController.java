package com.eazybytes.eazySchoolApp.controller;

import com.eazybytes.eazySchoolApp.model.Contact;
import com.eazybytes.eazySchoolApp.services.ContactService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;

import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

@Slf4j
@Controller
public class ContactController {

//    replaced by @Slf4j annotation
//    private static Logger log = LoggerFactory.getLogger(ContactController.class);

    private final ContactService contactService;

// read the value from application.properties directly
    @Value("${eazyschool.pageNumber}")
    private int pageNumber;

// read the variables defined in application.properties using environment Object
// + other environment variables
    @Autowired
    private Environment environment;

    @Autowired
    public ContactController(ContactService contactService){
        this.contactService = contactService;
    }

    @RequestMapping("/contact")
    public String displayContactPage(Model model){
        model.addAttribute("contact",new Contact());

        printPropertiesVariables();
        return "contact.html";
    }

// testing properties variables
    private void printPropertiesVariables(){
        log.error(String.format("eazyschool.pageNumber propeties = %d \n " +
                                "eazyschool.pageNumber propeties using enviornment = %s \n"+
                                "JAVA_HOME using enviornment = %s ",
                                pageNumber,environment.getProperty("eazyschool.pageNumber"),
                                environment.getProperty("JAVA_HOME")));
    }

//the RequestMapping annotation support both Get and Post methods
// in case we didn't define the method type it will support both
//
// the below annotation can be replaced by @PostMapping, and clear the method param

    //    @PostMapping("/saveMsg")
    @RequestMapping(value = "/saveMsg",method = POST)
    public String saveMessage(@Valid @ModelAttribute("contact") Contact contact, Errors error){
        if (error.hasErrors()){
            log.error("Contact form validation failed due to :" +error.toString());
            return "contact.html";
        }
        contactService.saveMessageDetails(contact);
        return "redirect:/contact";
    }

    @RequestMapping("/displayMessages/page/{pageNum}")
    public ModelAndView displayOpenMessages(Model model,
            @PathVariable(name="pageNum") int pageNum,
            @RequestParam(name="sortField") String sortField,
            @RequestParam(name="sortDir") String sortDir
    ){
//        List<Contact> contacts = contactService.findOpenMessages();
        Page<Contact> contactsPage = contactService.findOpenMessagesByPage(pageNum,sortField,sortDir);
        List<Contact> contacts = contactsPage.getContent();

        ModelAndView modelAndView = new ModelAndView("messages.html");

        modelAndView.addObject("contactMsgs",contacts);
        model.addAttribute("currentPage", pageNum);
        model.addAttribute("totalPages", contactsPage.getTotalPages());
        model.addAttribute("totalMsgs", contactsPage.getTotalElements());
        model.addAttribute("sortField", sortField);
        model.addAttribute("sortDir", sortDir);
        model.addAttribute("reverseSortDir", sortDir.equals("asc") ? "desc" : "asc");
        modelAndView.addObject("contactMsgs",contactsPage);
        return modelAndView;
    }

    @RequestMapping(value="/closeMsg",method = GET)
    public String CloseMessage(@RequestParam(value="id") int id){
        contactService.updateMsgStatus(id);
        return "redirect:/displayMessages/page/1?sortField=name&sortDir=desc";
    }

}
