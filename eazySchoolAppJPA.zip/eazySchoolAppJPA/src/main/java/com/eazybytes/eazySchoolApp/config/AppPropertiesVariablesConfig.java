package com.eazybytes.eazySchoolApp.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.util.Map;

@Component
@Data
@ConfigurationProperties(prefix = "eazyschool")
@Validated
public class AppPropertiesVariablesConfig {
    @Min(value=3,message="pageSize value should be greater than 3")
    @Max(value=10,message="pageSize value should be less than 10")
    private int pageSize;

// the name contact should match the name after the eazySchool (eazySchool.XXX) in application.properties
    private Map<String,String> contact;

}
