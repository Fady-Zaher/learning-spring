package com.eazybytes.eazySchoolApp.controller;

import com.eazybytes.eazySchoolApp.model.Courses;
import com.eazybytes.eazySchoolApp.model.EazyClass;
import com.eazybytes.eazySchoolApp.model.Person;
import com.eazybytes.eazySchoolApp.repositories.CoursesRepository;
import com.eazybytes.eazySchoolApp.repositories.EazyClassRepository;
import com.eazybytes.eazySchoolApp.repositories.PersonRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Slf4j
@Controller
@RequestMapping("admin")
public class AdminController {

    @Autowired
    EazyClassRepository eazyClassRepository;

    @Autowired
    PersonRepository personRepository;

    @Autowired
    CoursesRepository coursesRepository;

    @RequestMapping("/displayClasses")
    public ModelAndView displayClasses(){
        List<EazyClass> eazyClassList = eazyClassRepository.findAll();

        ModelAndView modelandView = new ModelAndView("classes.html");
        modelandView.addObject("eazyClass",new EazyClass());
        modelandView.addObject("eazyClasses",eazyClassList);
        return modelandView;
    }

    @PostMapping("/addNewClass")
    public String addNewClass(@ModelAttribute("eazyClass") EazyClass eazyClass){
        eazyClassRepository.save(eazyClass);
        return "redirect:/admin/displayClasses";
    }

    @RequestMapping("/deleteClass")
    public String deleteClass(@RequestParam int classId){
        Optional<EazyClass> eazyClass = eazyClassRepository.findById(classId);
        if (eazyClass.isPresent()){
            for (Person person: eazyClass.get().getPersons()){
                person.setEazyClass(null);
                personRepository.save(person);
            }
            eazyClassRepository.deleteById(classId);
        }
        return "redirect:/admin/displayClasses";
    }

    @GetMapping("/displayStudents")
    public ModelAndView displayStudents(@RequestParam int classId, HttpSession session,
                                        @RequestParam ( value="error", required = false) String error){
        String errorMessage = null;
        ModelAndView modelAndView = new ModelAndView("students.html");
        Optional<EazyClass> eazyClass = eazyClassRepository.findById(classId);
        modelAndView.addObject("eazyClass",eazyClass.get());
        modelAndView.addObject("person",new Person());
        session.setAttribute("eazyClass", eazyClass.get());

        if (error != null){
            errorMessage = "Invalid mail entered!";
            modelAndView.addObject("errorMessage",errorMessage);
        }

        return modelAndView;
    }

    @PostMapping("/addStudent")
    public ModelAndView addStudent(@ModelAttribute("person") Person person, HttpSession session){

        ModelAndView modelAndView = new ModelAndView();
        EazyClass currentClass = (EazyClass) session.getAttribute("eazyClass");
        Person personDetail = personRepository.findByEmail(person.getEmail());
        if (personDetail==null){
            modelAndView.setViewName("redirect:/admin/displayStudents?classId="+currentClass.getClassId() + "&error=true");
            return modelAndView;
        }

        personDetail.setEazyClass(currentClass);
        personRepository.save(personDetail);

        currentClass.getPersons().add(personDetail);
        eazyClassRepository.save(currentClass);

        modelAndView.setViewName("redirect:/admin/displayStudents?classId="+currentClass.getClassId());
        return modelAndView;
    }

    @RequestMapping("/deleteStudent")
    public String deleteStudent(@RequestParam("personId") int id, HttpSession session){
        EazyClass eazyClass = (EazyClass) session.getAttribute("eazyClass");
        Optional<Person> currentPerson = personRepository.findById(id);
        if (eazyClass !=null && currentPerson.isPresent()){
                eazyClass.getPersons().remove(currentPerson.get());
                currentPerson.get().setEazyClass(null);

                personRepository.save(currentPerson.get());
                eazyClassRepository.save(eazyClass);
                session.setAttribute("eazyClass", eazyClass);
        }
        return "redirect:/admin/displayStudents?classId="+eazyClass.getClassId();
    }

    @GetMapping("/displayCourses")
    public ModelAndView displayCourses(Model model) {
//        List<Courses> courses = coursesRepository.findAll();
//        List<Courses> courses = coursesRepository.findByOrderByNameDesc();
        List<Courses> courses = coursesRepository.findAll(Sort.by("name").ascending());

        ModelAndView modelAndView = new ModelAndView("courses_secure.html");
        modelAndView.addObject("courses",courses);
        modelAndView.addObject("course", new Courses());
        return modelAndView;
    }

    @PostMapping("/addNewCourse")
    public ModelAndView addNewCourse(Model model, @ModelAttribute("course") Courses course) {
        ModelAndView modelAndView = new ModelAndView();
        coursesRepository.save(course);
        modelAndView.setViewName("redirect:/admin/displayCourses");
        return modelAndView;
    }

    @GetMapping("/viewStudents")
    public ModelAndView viewStudents(Model model, @RequestParam int id
            ,HttpSession session,@RequestParam(required = false) String error) {
        String errorMessage = null;
        ModelAndView modelAndView = new ModelAndView("course_students.html");
        Optional<Courses> courses = coursesRepository.findById(id);
        modelAndView.addObject("courses",courses.get());
        modelAndView.addObject("person",new Person());
        session.setAttribute("currentCourse",courses.get());
        if(error != null) {
            errorMessage = "Invalid Email entered!!";
            modelAndView.addObject("errorMessage", errorMessage);
        }
        return modelAndView;
    }

    @PostMapping("/addStudentToCourse")
    public ModelAndView addStudentToCourse(Model model, @ModelAttribute("person") Person person,
                                           HttpSession session) {
        ModelAndView modelAndView = new ModelAndView();
        Courses courses = (Courses) session.getAttribute("currentCourse");
        Person personEntity = personRepository.findByEmail(person.getEmail());
        if(personEntity==null || !(personEntity.getPersonId()>0)){
            modelAndView.setViewName("redirect:/admin/viewStudents?id="+courses.getCourseId()
                    +"&error=true");
            return modelAndView;
        }
        personEntity.getCourses().add(courses);
        courses.getPersons().add(personEntity);
        personRepository.save(personEntity);
        session.setAttribute("currentCourse",courses);
        modelAndView.setViewName("redirect:/admin/viewStudents?id="+courses.getCourseId());
        return modelAndView;
    }

    @GetMapping("/deleteStudentFromCourse")
    public ModelAndView deleteStudentFromCourse(Model model, @RequestParam int personId,
                                                HttpSession session) {
        Courses courses = (Courses) session.getAttribute("currentCourse");
        Optional<Person> person = personRepository.findById(personId);
        person.get().getCourses().remove(courses);
        courses.getPersons().remove(person);
        personRepository.save(person.get());
        session.setAttribute("currentCourse",courses);
        ModelAndView modelAndView = new
                ModelAndView("redirect:/admin/viewStudents?id="+courses.getCourseId());
        return modelAndView;
    }
}
