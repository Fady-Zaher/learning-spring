package com.eazybytes.eazySchoolApp.controller;

import com.eazybytes.eazySchoolApp.constants.EazySchoolConstants;
import com.eazybytes.eazySchoolApp.model.Contact;
import com.eazybytes.eazySchoolApp.repositories.ContactRepository;
import com.eazybytes.eazySchoolApp.responses.ContactResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@RestController
@RequestMapping(path = "/api/contact",produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
@CrossOrigin(origins="http://localhost:8080")
public class ContactRestController {

    @Autowired
    ContactRepository contactRepository;

    @GetMapping("/getMsgsByStatus")
    //@ResponseBody
    public List<Contact> displayMsgsByStatus(@RequestParam String status){
        List<Contact> contacts = contactRepository.findByStatus(status);
        return contacts;
    }

    @GetMapping("/getMsgsByStatusContact")
    public List<Contact> displayMsgsByStatusContact(@RequestBody Contact contact){
        List<Contact> contacts = null;
        if (contact != null && contact.getStatus() != null){
            contacts = contactRepository.findByStatus(contact.getStatus());
        }
        return contacts;
    }

    // we use ResponseEntity in case we need to send header parameter with Body response
    @PostMapping("/saveMsg")
    public ResponseEntity<ContactResponse> saveContact (@RequestHeader("headerParam") String headerParam,
                                                        @Valid @RequestBody Contact contact){
        // logic related to headerParam, used for example to know from where we are calling the API
        log.info(String.format("Api called from : %s",headerParam));

        ContactResponse contactResponse = new ContactResponse();
        contactRepository.save(contact);
        contactResponse.setStatusMsg("Message Saved Successfully!");
        contactResponse.setStatusCode("200");

        return ResponseEntity.status(HttpStatus.CREATED)  // 201
                             .header("isMsgSaved","true")
                             .body(contactResponse);
    }

    @DeleteMapping("/deleteMsg")
    public ResponseEntity<ContactResponse> deleteMsg(RequestEntity<Contact> requestEntity){
        HttpHeaders headers = requestEntity.getHeaders();
        headers.forEach((key, value) -> {
            log.info(String.format(
                    "Header '%s' = %s", key, value.stream().collect(Collectors.joining("|"))));
        });
        Contact contact = requestEntity.getBody();
        contactRepository.deleteById(contact.getContactId());
        ContactResponse contactResponse = new ContactResponse();
        contactResponse.setStatusCode("200");
        contactResponse.setStatusMsg("Message successfully deleted");
        return ResponseEntity
                .status(HttpStatus.OK) // 200
                .body(contactResponse);
    }

    // Partial update
    @PatchMapping("/closeMsg")
    public ResponseEntity<ContactResponse> closeMsg(@RequestBody Contact contactReq){
        ContactResponse contactResponse = new ContactResponse();
        Optional<Contact> contact = contactRepository.findById(contactReq.getContactId());
        if(contact.isPresent()){
            contact.get().setStatus(EazySchoolConstants.CLOSE);
            contactRepository.save(contact.get());
        }else{
            contactResponse.setStatusCode("400");
            contactResponse.setStatusMsg("Invalid Contact ID received");
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST) // 400
                    .body(contactResponse);
        }
        contactResponse.setStatusCode("200");
        contactResponse.setStatusMsg("Message successfully closed");
        return ResponseEntity
                .status(HttpStatus.OK) // 200
                .body(contactResponse);
    }



}
